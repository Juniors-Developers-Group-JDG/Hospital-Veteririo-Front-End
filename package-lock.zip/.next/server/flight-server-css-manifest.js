self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\page.jsx": [
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\About\\about.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\exams\\exams.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\nav-utilities\\navUtilites.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\specialities\\specialities.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Services\\services.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Contact\\about.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Button\\button.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Home\\home.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\styles.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Footer\\footer.module.sass"
    ],
    "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\layout.jsx": [
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\node_modules\\next\\font\\google\\target.css?{\"path\":\"src\\\\app\\\\layout.jsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\globals.css",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\nav_bar\\NavBar.module.scss"
    ],
    "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\login\\page.jsx": [
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\form_components\\styles.sass",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\login\\styles.sass"
    ]
  },
  "cssModules": {
    "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\page": [
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\About\\about.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Contact\\about.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\styles.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Footer\\footer.module.sass",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\globals.css",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\node_modules\\next\\font\\google\\target.css?{\"path\":\"src\\\\app\\\\layout.jsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\nav_bar\\NavBar.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\exams\\exams.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\nav-utilities\\navUtilites.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\specialities\\specialities.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Services\\services.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Button\\button.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\Home\\home.module.scss"
    ],
    "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\login\\page": [
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\globals.css",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\node_modules\\next\\font\\google\\target.css?{\"path\":\"src\\\\app\\\\layout.jsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\nav_bar\\NavBar.module.scss",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\components\\form_components\\styles.sass",
      "C:\\Users\\carlo\\Desktop\\Hospital-Veteririo-Front-End-conectting-pages\\src\\app\\login\\styles.sass"
    ]
  }
}