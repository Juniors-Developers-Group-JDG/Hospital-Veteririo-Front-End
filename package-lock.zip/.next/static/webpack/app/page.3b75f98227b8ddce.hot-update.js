/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-client)/./src/components/Home/home.module.scss":
/*!**********************************************!*\
  !*** ./src/components/Home/home.module.scss ***!
  \**********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"main\":\"home_main__E5_Ct\",\"left_text\":\"home_left_text___CAj6\",\"title\":\"home_title__EBsGz\",\"slogan\":\"home_slogan__ofYYr\",\"pets_icon\":\"home_pets_icon__rkNG2\",\"animal\":\"home_animal__pFmPy\",\"pet\":\"home_pet__P_smM\",\"right_img\":\"home_right_img__Vw5_E\",\"box_img\":\"home_box_img__k71a7\"};\n    if(true) {\n      // 1686244085939\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-client)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"cd0b2669f88e\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1jbGllbnQpLy4vc3JjL2NvbXBvbmVudHMvSG9tZS9ob21lLm1vZHVsZS5zY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0Esa0JBQWtCO0FBQ2xCLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLGlNQUEwSixjQUFjLHNEQUFzRDtBQUM1UCxNQUFNLFVBQVU7QUFDaEI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9jb21wb25lbnRzL0hvbWUvaG9tZS5tb2R1bGUuc2Nzcz80YzIwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxubW9kdWxlLmV4cG9ydHMgPSB7XCJtYWluXCI6XCJob21lX21haW5fX0U1X0N0XCIsXCJsZWZ0X3RleHRcIjpcImhvbWVfbGVmdF90ZXh0X19fQ0FqNlwiLFwidGl0bGVcIjpcImhvbWVfdGl0bGVfX0VCc0d6XCIsXCJzbG9nYW5cIjpcImhvbWVfc2xvZ2FuX19vZllZclwiLFwicGV0c19pY29uXCI6XCJob21lX3BldHNfaWNvbl9fcmtORzJcIixcImFuaW1hbFwiOlwiaG9tZV9hbmltYWxfX3BGbVB5XCIsXCJwZXRcIjpcImhvbWVfcGV0X19QX3NtTVwiLFwicmlnaHRfaW1nXCI6XCJob21lX3JpZ2h0X2ltZ19fVnc1X0VcIixcImJveF9pbWdcIjpcImhvbWVfYm94X2ltZ19fazcxYTdcIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTY4NjI0NDA4NTkzOVxuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJDOi9Vc2Vycy9jYXJsby9EZXNrdG9wL0hvc3BpdGFsLVZldGVyaXJpby1Gcm9udC1FbmQtY29uZWN0dGluZy1wYWdlcy9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcInB1YmxpY1BhdGhcIjpcIi9fbmV4dC9cIixcImVzTW9kdWxlXCI6ZmFsc2UsXCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgXG5tb2R1bGUuZXhwb3J0cy5fX2NoZWNrc3VtID0gXCJjZDBiMjY2OWY4OGVcIlxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-client)/./src/components/Home/home.module.scss\n"));

/***/ })

});