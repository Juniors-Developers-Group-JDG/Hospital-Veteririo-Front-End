/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-client)/./src/components/About/about.module.scss":
/*!************************************************!*\
  !*** ./src/components/About/about.module.scss ***!
  \************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"section_about\":\"about_section_about__7jb5m\",\"title\":\"about_title__smqkM\",\"group_about\":\"about_group_about__2k_Hx\",\"img_about\":\"about_img_about__SbOrI\",\"text_about\":\"about_text_about__HLjv8\",\"box_text\":\"about_box_text__VEQE9\"};\n    if(true) {\n      // 1686246562278\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-client)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"717e0f7a4341\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1jbGllbnQpLy4vc3JjL2NvbXBvbmVudHMvQWJvdXQvYWJvdXQubW9kdWxlLnNjc3MuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQSxrQkFBa0I7QUFDbEIsT0FBTyxJQUFVO0FBQ2pCO0FBQ0Esc0JBQXNCLG1CQUFPLENBQUMsaU1BQTBKLGNBQWMsc0RBQXNEO0FBQzVQLE1BQU0sVUFBVTtBQUNoQjtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvQWJvdXQvYWJvdXQubW9kdWxlLnNjc3M/MmZhOSJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbm1vZHVsZS5leHBvcnRzID0ge1wic2VjdGlvbl9hYm91dFwiOlwiYWJvdXRfc2VjdGlvbl9hYm91dF9fN2piNW1cIixcInRpdGxlXCI6XCJhYm91dF90aXRsZV9fc21xa01cIixcImdyb3VwX2Fib3V0XCI6XCJhYm91dF9ncm91cF9hYm91dF9fMmtfSHhcIixcImltZ19hYm91dFwiOlwiYWJvdXRfaW1nX2Fib3V0X19TYk9ySVwiLFwidGV4dF9hYm91dFwiOlwiYWJvdXRfdGV4dF9hYm91dF9fSExqdjhcIixcImJveF90ZXh0XCI6XCJhYm91dF9ib3hfdGV4dF9fVkVRRTlcIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTY4NjI0NjU2MjI3OFxuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJDOi9Vc2Vycy9jYXJsby9EZXNrdG9wL0hvc3BpdGFsLVZldGVyaXJpby1Gcm9udC1FbmQtY29uZWN0dGluZy1wYWdlcy9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcInB1YmxpY1BhdGhcIjpcIi9fbmV4dC9cIixcImVzTW9kdWxlXCI6ZmFsc2UsXCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgXG5tb2R1bGUuZXhwb3J0cy5fX2NoZWNrc3VtID0gXCI3MTdlMGY3YTQzNDFcIlxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-client)/./src/components/About/about.module.scss\n"));

/***/ })

});