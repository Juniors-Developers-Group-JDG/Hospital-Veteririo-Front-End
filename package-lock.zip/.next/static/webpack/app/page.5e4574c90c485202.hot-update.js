/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-client)/./src/components/Home/home.module.scss":
/*!**********************************************!*\
  !*** ./src/components/Home/home.module.scss ***!
  \**********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"main\":\"home_main__E5_Ct\",\"left_text\":\"home_left_text___CAj6\",\"title\":\"home_title__EBsGz\",\"slogan\":\"home_slogan__ofYYr\",\"pets_icon\":\"home_pets_icon__rkNG2\",\"animal\":\"home_animal__pFmPy\",\"pet\":\"home_pet__P_smM\"};\n    if(true) {\n      // 1686243063118\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-client)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"5c53969e1182\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1jbGllbnQpLy4vc3JjL2NvbXBvbmVudHMvSG9tZS9ob21lLm1vZHVsZS5zY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0Esa0JBQWtCO0FBQ2xCLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLGlNQUEwSixjQUFjLHNEQUFzRDtBQUM1UCxNQUFNLFVBQVU7QUFDaEI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9jb21wb25lbnRzL0hvbWUvaG9tZS5tb2R1bGUuc2Nzcz80YzIwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxubW9kdWxlLmV4cG9ydHMgPSB7XCJtYWluXCI6XCJob21lX21haW5fX0U1X0N0XCIsXCJsZWZ0X3RleHRcIjpcImhvbWVfbGVmdF90ZXh0X19fQ0FqNlwiLFwidGl0bGVcIjpcImhvbWVfdGl0bGVfX0VCc0d6XCIsXCJzbG9nYW5cIjpcImhvbWVfc2xvZ2FuX19vZllZclwiLFwicGV0c19pY29uXCI6XCJob21lX3BldHNfaWNvbl9fcmtORzJcIixcImFuaW1hbFwiOlwiaG9tZV9hbmltYWxfX3BGbVB5XCIsXCJwZXRcIjpcImhvbWVfcGV0X19QX3NtTVwifTtcbiAgICBpZihtb2R1bGUuaG90KSB7XG4gICAgICAvLyAxNjg2MjQzMDYzMTE4XG4gICAgICB2YXIgY3NzUmVsb2FkID0gcmVxdWlyZShcIkM6L1VzZXJzL2NhcmxvL0Rlc2t0b3AvSG9zcGl0YWwtVmV0ZXJpcmlvLUZyb250LUVuZC1jb25lY3R0aW5nLXBhZ2VzL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY29tcGlsZWQvbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4vaG1yL2hvdE1vZHVsZVJlcGxhY2VtZW50LmpzXCIpKG1vZHVsZS5pZCwge1wicHVibGljUGF0aFwiOlwiL19uZXh0L1wiLFwiZXNNb2R1bGVcIjpmYWxzZSxcImxvY2Fsc1wiOnRydWV9KTtcbiAgICAgIG1vZHVsZS5ob3QuZGlzcG9zZShjc3NSZWxvYWQpO1xuICAgICAgXG4gICAgfVxuICBcbm1vZHVsZS5leHBvcnRzLl9fY2hlY2tzdW0gPSBcIjVjNTM5NjllMTE4MlwiXG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(app-client)/./src/components/Home/home.module.scss\n"));

/***/ })

});